import gradio as gr
from main import IntentRecognitionSystem
import json

# 请替换为您的API Key
API_KEY = "1661f7bfead0488e8942bee88e339ed2.zC4iMdf5417Eq4Sw"

# 初始化系统
system = IntentRecognitionSystem(
    intent_schema_path='intent_schema.json',
    api_key=API_KEY,
    api_provider='zhipu'  # 使用智谱AI（推荐）
)

def recognize_intent(user_input):
    """Gradio回调函数"""
    result = system.process(user_input)
    return json.dumps(result, ensure_ascii=False, indent=2)

# 创建Gradio界面
demo = gr.Interface(
    fn=recognize_intent,
    inputs=gr.Textbox(
        label="用户输入",
        placeholder="请输入客服咨询内容...",
        lines=3
    ),
    outputs=gr.JSON(label="识别结果"),
    title="客服意图识别系统（零成本云端版）",
    description="基于智谱AI GLM-4-Flash的免费意图识别方案",
    examples=[
        ["我的订单什么时候发货？"],
        ["怎么还没发货？等了3天了"],
        ["我要退款"],
        ["这个产品怎么用？"],
        ["有优惠吗？"],
        ["还有货吗？"],
    ],
    theme=gr.themes.Soft()
)

if __name__ == "__main__":
    demo.launch(
        server_name="0.0.0.0",  # 允许外部访问
        server_port=7860,
        share=False  # 如需公网访问，设置为True
    )
