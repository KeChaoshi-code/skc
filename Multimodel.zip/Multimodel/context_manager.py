import json
from datetime import datetime, timedelta
from collections import defaultdict

class ContextManager:
    def __init__(self, max_history=5, session_timeout=30):
        """
        对话上下文管理器
        
        max_history: 保留的最大历史轮数
        session_timeout: 会话超时时间（分钟）
        """
        self.max_history = max_history
        self.session_timeout = timedelta(minutes=session_timeout)
        self.sessions = defaultdict(lambda: {
            'history': [],
            'last_intent': None,
            'last_update': None,
            'context_info': {}
        })
    
    def add_turn(self, session_id, user_input, intent, confidence, extracted_info=None):
        """添加一轮对话"""
        session = self.sessions[session_id]
        
        # 检查会话是否超时
        if session['last_update']:
            if datetime.now() - session['last_update'] > self.session_timeout:
                self.clear_session(session_id)
                session = self.sessions[session_id]
        
        # 添加对话历史
        turn = {
            'user_input': user_input,
            'intent': intent,
            'confidence': confidence,
            'timestamp': datetime.now().isoformat(),
            'extracted_info': extracted_info or {}
        }
        
        session['history'].append(turn)
        
        # 保持历史长度限制
        if len(session['history']) > self.max_history:
            session['history'] = session['history'][-self.max_history:]
        
        # 更新上下文信息
        session['last_intent'] = intent
        session['last_update'] = datetime.now()
        
        # 累积提取的信息
        if extracted_info:
            session['context_info'].update(extracted_info)
    
    def get_context(self, session_id):
        """获取会话上下文"""
        session = self.sessions[session_id]
        
        # 检查会话是否超时
        if session['last_update']:
            if datetime.now() - session['last_update'] > self.session_timeout:
                return None
        
        return {
            'history': session['history'],
            'last_intent': session['last_intent'],
            'context_info': session['context_info']
        }
    
    def get_history_text(self, session_id, num_turns=3):
        """获取历史对话文本（用于Prompt）"""
        context = self.get_context(session_id)
        if not context or not context['history']:
            return ""
        
        history = context['history'][-num_turns:]
        history_text = "\n".join([
            f"用户: {turn['user_input']}\n识别意图: {turn['intent']}"
            for turn in history
        ])
        
        return history_text
    
    def clear_session(self, session_id):
        """清除会话"""
        if session_id in self.sessions:
            del self.sessions[session_id]
    
    def is_clarification_needed(self, session_id, current_confidence):
        """判断是否需要澄清"""
        context = self.get_context(session_id)
        
        # 如果置信度低于阈值，需要澄清
        if current_confidence < 0.6:
            return True
        
        # 如果上一轮也是低置信度，需要澄清
        if context and context['history']:
            last_turn = context['history'][-1]
            if last_turn['confidence'] < 0.7:
                return True
        
        return False
    
    def generate_clarification_question(self, session_id, possible_intents):
        """生成澄清性问题"""
        if len(possible_intents) <= 1:
            return "抱歉，我没有理解您的意思，能否详细说明一下？"
        
        # 生成选项
        options = "\n".join([
            f"{i+1}. {intent}" 
            for i, intent in enumerate(possible_intents[:3])
        ])
        
        return f"我不太确定您的意思，请问您是想：\n{options}\n\n请告诉我对应的数字或重新描述。"
