import os
import tempfile
import requests

class ASRProcessor:
    def __init__(self, api_key, asr_provider='zhipu'):
        """
        语音识别处理器
        
        asr_provider: 'zhipu' (智谱AI) 或 'openai' (OpenAI Whisper API)
        """
        self.api_key = api_key
        self.asr_provider = asr_provider
        
        if asr_provider == 'zhipu':
            # 智谱AI暂不支持ASR，使用本地Whisper
            self.use_local_whisper = True
        elif asr_provider == 'openai':
            self.api_url = "https://api.openai.com/v1/audio/transcriptions"
            self.use_local_whisper = False
    
    def transcribe_audio(self, audio_file_path ):
        """
        语音转文字
        
        audio_file_path: 音频文件路径（支持 mp3, wav, m4a, webm）
        """
        if self.use_local_whisper:
            return self._transcribe_local(audio_file_path)
        else:
            return self._transcribe_api(audio_file_path)
    
    def _transcribe_local(self, audio_file_path):
        """使用本地Whisper模型"""
        try:
            import whisper
            
            # 加载模型（首次运行会下载，约140MB）
            model = whisper.load_model("base")  # 可选: tiny, base, small, medium, large
            
            # 转录
            result = model.transcribe(audio_file_path, language="zh")
            
            return result["text"], None
        
        except Exception as e:
            return None, f"语音识别失败: {str(e)}"
    
    def _transcribe_api(self, audio_file_path):
        """使用API进行语音识别"""
        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}"
            }
            
            with open(audio_file_path, 'rb') as audio_file:
                files = {
                    'file': audio_file,
                    'model': (None, 'whisper-1'),
                    'language': (None, 'zh')
                }
                
                response = requests.post(
                    self.api_url,
                    headers=headers,
                    files=files,
                    timeout=30
                )
            
            if response.status_code == 200:
                result = response.json()
                return result['text'], None
            else:
                return None, f"API错误: {response.status_code}"
        
        except Exception as e:
            return None, f"语音识别失败: {str(e)}"
    
    def process_audio_bytes(self, audio_bytes, format='wav'):
        """处理音频字节流"""
        # 保存为临时文件
        with tempfile.NamedTemporaryFile(suffix=f'.{format}', delete=False) as tmp_file:
            tmp_file.write(audio_bytes)
            tmp_path = tmp_file.name
        
        try:
            text, error = self.transcribe_audio(tmp_path)
            return text, error
        finally:
            # 清理临时文件
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
