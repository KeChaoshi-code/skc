import re

class TextPreprocessor:
    def __init__(self):
        self.max_length = 512
        self.sensitive_words = []  # 可配置敏感词
    
    def clean_text(self, text):
        """文本清洗"""
        # 去除特殊字符（保留中文、英文、数字、空格）
        text = re.sub(r'[^\w\s\u4e00-\u9fff]', '', text)
        # 去除多余空格
        text = ' '.join(text.split())
        return text.strip()
    
    def filter_sensitive(self, text):
        """敏感词过滤"""
        for word in self.sensitive_words:
            if word in text:
                return True, word
        return False, None
    
    def truncate(self, text):
        """长度控制"""
        if len(text) > self.max_length:
            return text[:self.max_length]
        return text
    
    def validate(self, text):
        """输入验证"""
        if not text or len(text.strip()) == 0:
            return False, "输入为空"
        if len(text) < 2:
            return False, "输入过短"
        return True, None
    
    def preprocess(self, text):
        """完整预处理流程"""
        # 验证
        is_valid, error = self.validate(text)
        if not is_valid:
            return None, error
        
        # 清洗
        text = self.clean_text(text)
        
        # 敏感词过滤
        has_sensitive, word = self.filter_sensitive(text)
        if has_sensitive:
            return None, f"包含敏感词：{word}"
        
        # 长度控制
        text = self.truncate(text)
        
        return text, None
