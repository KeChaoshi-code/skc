"""
生成测试订单截图（用于测试OCR功能）
"""
from PIL import Image, ImageDraw, ImageFont
import os

def generate_order_screenshot():
    """生成模拟订单截图"""
    # 创建图片
    img = Image.new('RGB', (800, 600), color='white')
    draw = ImageDraw.Draw(img)
    
    # 尝试使用系统字体
    try:
        font_large = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 36)
        font_medium = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 24)
        font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)
    except:
        font_large = ImageFont.load_default()
        font_medium = ImageFont.load_default()
        font_small = ImageFont.load_default()
    
    # 绘制订单信息
    y_offset = 50
    
    # 标题
    draw.text((50, y_offset), "订单详情", fill='black', font=font_large)
    y_offset += 80
    
    # 订单号
    draw.text((50, y_offset), "订单号：", fill='gray', font=font_medium)
    draw.text((200, y_offset), "OD20241104123456", fill='black', font=font_medium)
    y_offset += 50
    
    # 订单状态
    draw.text((50, y_offset), "订单状态：", fill='gray', font=font_medium)
    draw.text((200, y_offset), "待发货", fill='orange', font=font_medium)
    y_offset += 50
    
    # 下单时间
    draw.text((50, y_offset), "下单时间：", fill='gray', font=font_medium)
    draw.text((200, y_offset), "2024-11-01 14:30", fill='black', font=font_medium)
    y_offset += 50
    
    # 商品金额
    draw.text((50, y_offset), "商品金额：", fill='gray', font=font_medium)
    draw.text((200, y_offset), "¥ 299.00", fill='red', font=font_medium)
    y_offset += 80
    
    # 商品信息
    draw.rectangle([50, y_offset, 750, y_offset+150], outline='lightgray', width=2)
    draw.text((70, y_offset+20), "商品名称：智能手表", fill='black', font=font_small)
    draw.text((70, y_offset+60), "数量：1", fill='gray', font=font_small)
    draw.text((70, y_offset+100), "规格：黑色/标准版", fill='gray', font=font_small)
    
    # 保存图片
    output_path = 'test_order_screenshot.jpg'
    img.save(output_path)
    print(f"✓ 测试订单截图已生成：{output_path}")
    
    return output_path

if __name__ == "__main__":
    generate_order_screenshot()
