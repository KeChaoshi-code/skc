from multimodal_system import MultimodalIntentSystem
import json

# 请替换为您的API Key
API_KEY = "your_api_key_here"

system = MultimodalIntentSystem(
    intent_schema_path='intent_schema.json',
    api_key=API_KEY,
    api_provider='zhipu'
)

print("=== 多模态意图识别系统测试 ===\n")

# 测试1：文本输入（无上下文）
print("【测试1】文本输入（无上下文）")
result = system.process_text("我的订单什么时候发货？")
print(f"输入：我的订单什么时候发货？")
print(f"意图：{result['intent']}")
print(f"置信度：{result['confidence']:.2%}")
print(f"会话ID：{result['session_id']}\n")

# 测试2：文本输入（带上下文）
print("【测试2】文本输入（带上下文）")
session_id = result['session_id']
result2 = system.process_text("怎么还没发货？", session_id)
print(f"输入：怎么还没发货？")
print(f"意图：{result2['intent']}")
print(f"置信度：{result2['confidence']:.2%}")
print(f"上下文：{len(result2['context']['history'])}轮对话\n")

# 测试3：低置信度澄清
print("【测试3】低置信度澄清")
result3 = system.process_text("这个", session_id)
print(f"输入：这个")
print(f"意图：{result3['intent']}")
print(f"置信度：{result3['confidence']:.2%}")
print(f"需要澄清：{result3['need_clarification']}")
if result3['need_clarification']:
    print(f"澄清问题：{result3['clarification_question']}\n")

# 测试4：查看会话上下文
print("【测试4】查看会话上下文")
context = system.context_manager.get_context(session_id)
print(f"会话ID：{session_id}")
print(f"对话历史：{len(context['history'])}轮")
print(f"最后意图：{context['last_intent']}")
print("\n对话历史：")
for i, turn in enumerate(context['history'], 1):
    print(f"  {i}. {turn['user_input']} → {turn['intent']} ({turn['confidence']:.2%})")

print("\n=== 测试完成 ===")
