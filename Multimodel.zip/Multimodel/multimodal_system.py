from preprocessor import TextPreprocessor
from intent_recognizer import IntentRecognizer
from postprocessor import PostProcessor
from context_manager import ContextManager
from asr_processor import ASRProcessor
from image_processor import ImageProcessor
import json
import uuid

class MultimodalIntentSystem:
    def __init__(self, intent_schema_path, api_key, api_provider='zhipu'):
        """
        多模态意图识别系统
        
        支持：文本、语音、图片输入
        """
        with open(intent_schema_path, 'r', encoding='utf-8') as f:
            intent_schema = json.load(f)
        
        # 初始化各模块
        self.preprocessor = TextPreprocessor()
        self.recognizer = IntentRecognizer(intent_schema_path, api_key, api_provider)
        self.postprocessor = PostProcessor(intent_schema)
        self.context_manager = ContextManager(max_history=5, session_timeout=30)
        self.asr_processor = ASRProcessor(api_key, asr_provider='zhipu')
        self.image_processor = ImageProcessor(api_key, ocr_provider='paddleocr')
        
        self.intent_schema = intent_schema
    
    def process_text(self, user_input, session_id=None):
        """处理文本输入"""
        if session_id is None:
            session_id = str(uuid.uuid4())
        
        # 1. 预处理
        cleaned_text, error = self.preprocessor.preprocess(user_input)
        if error:
            return {"error": error, "raw_input": user_input, "session_id": session_id}
        
        # 2. 获取上下文
        context = self.context_manager.get_context(session_id)
        history_text = self.context_manager.get_history_text(session_id, num_turns=3)
        
        # 3. 意图识别（带上下文）
        intent = self.recognizer.recognize_with_context(cleaned_text, history_text)
        
        # 4. 后处理
        confidence = self.postprocessor.calculate_confidence(intent, cleaned_text)
        is_anomaly, anomaly_reason = self.postprocessor.detect_anomaly(intent, confidence)
        
        # 5. 判断是否需要澄清
        need_clarification = self.context_manager.is_clarification_needed(session_id, confidence)
        clarification_question = None
        
        if need_clarification:
            # 获取可能的意图列表（置信度前3）
            possible_intents = list(self.intent_schema.keys())[:3]
            clarification_question = self.context_manager.generate_clarification_question(
                session_id, possible_intents
            )
        
        # 6. 更新上下文
        self.context_manager.add_turn(
            session_id, user_input, intent, confidence
        )
        
        # 7. 格式化结果
        result = self.postprocessor.format_result(
            intent, confidence, user_input, is_anomaly, anomaly_reason
        )
        
        result['session_id'] = session_id
        result['need_clarification'] = need_clarification
        result['clarification_question'] = clarification_question
        result['context'] = context
        
        return result
    
    def process_audio(self, audio_file_path, session_id=None):
        """处理语音输入"""
        if session_id is None:
            session_id = str(uuid.uuid4())
        
        # 1. 语音转文字
        text, error = self.asr_processor.transcribe_audio(audio_file_path)
        
        if error:
            return {
                "error": error,
                "session_id": session_id,
                "input_type": "audio"
            }
        
        # 2. 处理文本
        result = self.process_text(text, session_id)
        result['input_type'] = 'audio'
        result['transcribed_text'] = text
        
        return result
    
    def process_image(self, image_file_path, session_id=None):
        """处理图片输入"""
        if session_id is None:
            session_id = str(uuid.uuid4())
        
        # 1. OCR提取文字
        ocr_result, error = self.image_processor.extract_order_info(image_file_path)
        
        if error:
            return {
                "error": error,
                "session_id": session_id,
                "input_type": "image"
            }
        
        # 2. 处理提取的文本
        text = ocr_result['raw_text']
        extracted_info = ocr_result['extracted_info']
        
        result = self.process_text(text, session_id)
        result['input_type'] = 'image'
        result['ocr_text'] = text
        result['extracted_info'] = extracted_info
        
        # 3. 更新上下文信息
        self.context_manager.add_turn(
            session_id, 
            f"[图片输入] {text[:50]}...",
            result['intent'],
            result['confidence'],
            extracted_info
        )
        
        return result
    
    def clear_context(self, session_id):
        """清除会话上下文"""
        self.context_manager.clear_session(session_id)
