import gradio as gr
from multimodal_system import MultimodalIntentSystem
import json
import os

# 请替换为您的API Key
API_KEY = "your_api_key_here"

# 初始化多模态系统
system = MultimodalIntentSystem(
    intent_schema_path='intent_schema.json',
    api_key=API_KEY,
    api_provider='zhipu'
)

# 全局会话ID存储
current_sessions = {}

def process_text_input(text, session_id):
    """处理文本输入"""
    if not text:
        return "请输入文本", "", session_id
    
    # 如果没有session_id，创建新的
    if not session_id:
        import uuid
        session_id = str(uuid.uuid4())
    
    result = system.process_text(text, session_id)
    
    # 格式化输出
    output = format_result(result)
    
    # 如果需要澄清，显示澄清问题
    clarification = ""
    if result.get('need_clarification'):
        clarification = f"🤔 {result.get('clarification_question', '')}"
    
    return output, clarification, session_id

def process_audio_input(audio, session_id):
    """处理语音输入"""
    if audio is None:
        return "请上传音频文件", "", session_id
    
    # 如果没有session_id，创建新的
    if not session_id:
        import uuid
        session_id = str(uuid.uuid4())
    
    result = system.process_audio(audio, session_id)
    
    # 格式化输出
    output = format_result(result)
    
    # 显示转录文本
    transcribed = ""
    if 'transcribed_text' in result:
        transcribed = f"📝 转录文本：{result['transcribed_text']}\n\n"
    
    clarification = ""
    if result.get('need_clarification'):
        clarification = f"🤔 {result.get('clarification_question', '')}"
    
    return transcribed + output, clarification, session_id

def process_image_input(image, session_id):
    """处理图片输入"""
    if image is None:
        return "请上传图片", "", session_id
    
    # 如果没有session_id，创建新的
    if not session_id:
        import uuid
        session_id = str(uuid.uuid4())
    
    result = system.process_image(image, session_id)
    
    # 格式化输出
    output = format_result(result)
    
    # 显示OCR文本和提取信息
    ocr_info = ""
    if 'ocr_text' in result:
        ocr_info = f"📄 识别文本：\n{result['ocr_text']}\n\n"
    
    if 'extracted_info' in result and result['extracted_info']:
        ocr_info += "🔍 提取信息：\n"
        for key, value in result['extracted_info'].items():
            ocr_info += f"  • {key}: {value}\n"
        ocr_info += "\n"
    
    clarification = ""
    if result.get('need_clarification'):
        clarification = f"🤔 {result.get('clarification_question', '')}"
    
    return ocr_info + output, clarification, session_id

def format_result(result):
    """格式化识别结果"""
    if 'error' in result:
        return f"❌ 错误：{result['error']}"
    
    output = f"""
✅ **识别结果**

🎯 **意图**：{result['intent']}
📊 **置信度**：{result['confidence']:.2%}
⏰ **时间**：{result['timestamp']}

---

📝 **原始输入**：{result['raw_input']}

"""
    
    # 显示上下文信息
    if result.get('context') and result['context'].get('history'):
        output += "\n📚 **对话历史**：\n"
        for i, turn in enumerate(result['context']['history'][-3:], 1):
            output += f"{i}. {turn['user_input']} → {turn['intent']}\n"
    
    # 显示异常信息
    if result.get('is_anomaly'):
        output += f"\n⚠️ **异常检测**：{result.get('error', '未知异常')}\n"
    
    return output

def clear_session(session_id):
    """清除会话"""
    if session_id:
        system.clear_context(session_id)
    return "", "", ""

def show_context(session_id):
    """显示当前会话上下文"""
    if not session_id:
        return "无活动会话"
    
    context = system.context_manager.get_context(session_id)
    
    if not context:
        return "会话已过期或不存在"
    
    output = f"""
📋 **会话信息**

🆔 **会话ID**：{session_id}
🕐 **最后更新**：{context.get('last_update', 'N/A')}
🎯 **上一意图**：{context.get('last_intent', 'N/A')}

---

📚 **对话历史**（最近{len(context.get('history', []))}轮）：

"""
    
    for i, turn in enumerate(context.get('history', []), 1):
        output += f"""
**第{i}轮**
  • 用户输入：{turn['user_input']}
  • 识别意图：{turn['intent']}
  • 置信度：{turn['confidence']:.2%}
  • 时间：{turn['timestamp']}
"""
    
    if context.get('context_info'):
        output += "\n🔍 **累积信息**：\n"
        for key, value in context['context_info'].items():
            output += f"  • {key}: {value}\n"
    
    return output

# 创建Gradio界面
with gr.Blocks(theme=gr.themes.Soft(), title="多模态客服意图识别系统") as demo:
    gr.Markdown("""
    # 🤖 多模态客服意图识别系统（增强版）
    
    支持**文本**、**语音**、**图片**三种输入方式，具备**上下文记忆**和**澄清性问题**功能。
    
    ### 功能特性
    - ✅ 文本输入：直接输入客服咨询
    - ✅ 语音输入：上传音频文件（支持 mp3, wav, m4a）
    - ✅ 图片输入：上传订单截图（自动OCR识别）
    - ✅ 上下文记忆：维护多轮对话历史
    - ✅ 澄清性问题：低置信度时主动询问
    """)
    
    # 会话ID状态
    session_state = gr.State(value="")
    
    with gr.Tabs():
        # Tab 1: 文本输入
        with gr.Tab("💬 文本输入"):
            with gr.Row():
                with gr.Column(scale=2):
                    text_input = gr.Textbox(
                        label="用户输入",
                        placeholder="请输入客服咨询内容...",
                        lines=3
                    )
                    text_btn = gr.Button("🚀 识别意图", variant="primary")
                    
                    gr.Examples(
                        examples=[
                            ["我的订单什么时候发货？"],
                            ["怎么还没发货？等了3天了"],
                            ["我要退款"],
                            ["这个产品怎么用？"],
                            ["有优惠吗？"],
                            ["还有货吗？"],
                        ],
                        inputs=text_input
                    )
                
                with gr.Column(scale=3):
                    text_output = gr.Markdown(label="识别结果")
                    text_clarification = gr.Markdown(label="澄清问题")
        
        # Tab 2: 语音输入
        with gr.Tab("🎤 语音输入"):
            with gr.Row():
                with gr.Column(scale=2):
                    audio_input = gr.Audio(
                        label="上传音频文件",
                        type="filepath",
                        sources=["upload", "microphone"]
                    )
                    audio_btn = gr.Button("🚀 识别意图", variant="primary")
                    
                    gr.Markdown("""
                    **支持格式**：mp3, wav, m4a, webm
                    
                    **使用说明**：
                    1. 点击"Upload"上传音频文件
                    2. 或点击"Record"直接录音
                    3. 点击"识别意图"按钮
                    """)
                
                with gr.Column(scale=3):
                    audio_output = gr.Markdown(label="识别结果")
                    audio_clarification = gr.Markdown(label="澄清问题")
        
        # Tab 3: 图片输入
        with gr.Tab("📷 图片输入"):
            with gr.Row():
                with gr.Column(scale=2):
                    image_input = gr.Image(
                        label="上传订单截图",
                        type="filepath"
                    )
                    image_btn = gr.Button("🚀 识别意图", variant="primary")
                    
                    gr.Markdown("""
                    **支持格式**：jpg, png, jpeg
                    
                    **使用说明**：
                    1. 上传订单截图或相关图片
                    2. 系统自动OCR识别文字
                    3. 提取订单号、金额等信息
                    4. 识别用户意图
                    """)
                
                with gr.Column(scale=3):
                    image_output = gr.Markdown(label="识别结果")
                    image_clarification = gr.Markdown(label="澄清问题")
        
        # Tab 4: 会话管理
        with gr.Tab("📋 会话管理"):
            gr.Markdown("""
            ### 会话上下文管理
            
            查看当前会话的对话历史和上下文信息。
            """)
            
            with gr.Row():
                show_context_btn = gr.Button("📊 查看会话上下文", variant="secondary")
                clear_context_btn = gr.Button("🗑️ 清除会话", variant="stop")
            
            context_output = gr.Markdown(label="会话上下文")
            
            session_info = gr.Markdown(f"**当前会话ID**：未创建")
    
    # 绑定事件
    text_btn.click(
        fn=process_text_input,
        inputs=[text_input, session_state],
        outputs=[text_output, text_clarification, session_state]
    )
    
    audio_btn.click(
        fn=process_audio_input,
        inputs=[audio_input, session_state],
        outputs=[audio_output, audio_clarification, session_state]
    )
    
    image_btn.click(
        fn=process_image_input,
        inputs=[image_input, session_state],
        outputs=[image_output, image_clarification, session_state]
    )
    
    show_context_btn.click(
        fn=show_context,
        inputs=[session_state],
        outputs=[context_output]
    )
    
    clear_context_btn.click(
        fn=clear_session,
        inputs=[session_state],
        outputs=[text_output, text_clarification, session_state]
    )

if __name__ == "__main__":
    demo.launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False  # 设置为True可生成公网链接
    )
