import requests
import json
import time

class IntentRecognizer:
    def __init__(self, intent_schema_path, api_key, api_provider='zhipu'):
        """
        初始化意图识别器
        
        api_provider: 'zhipu' (智谱AI) 或 'siliconflow' (硅基流动)
        """
        with open(intent_schema_path, 'r', encoding='utf-8') as f:
            self.intent_schema = json.load(f)
        
        self.api_key = api_key
        self.api_provider = api_provider
        
        # 配置不同API提供商的参数
        if api_provider == 'zhipu':
            self.api_url = "https://open.bigmodel.cn/api/paas/v4/chat/completions"
            self.model_name = "glm-4-flash"
        elif api_provider == 'siliconflow':
            self.api_url = "https://api.siliconflow.cn/v1/chat/completions"
            self.model_name = "Qwen/Qwen2.5-7B-Instruct"
        else:
            raise ValueError(f"不支持的API提供商: {api_provider}" )
    
    def build_prompt(self, user_input):
        """构建Prompt"""
        intent_list = []
        for i, (intent_name, intent_info) in enumerate(self.intent_schema.items(), 1):
            examples_str = "、".join(intent_info['examples'][:3])
            intent_list.append(
                f"{i}. {intent_name}\n"
                f"   描述：{intent_info['description']}\n"
                f"   示例：{examples_str}"
            )
        
        intent_desc = "\n\n".join(intent_list)
        
        prompt = f"""你是一个专业的客服意图识别专家。请根据用户输入，从以下意图中选择最匹配的一个。

意图列表：
{intent_desc}

用户输入：{user_input}

要求：
1. 只输出意图标签（如"咨询订单"），不要输出其他内容
2. 如果无法判断，输出"其他咨询"
3. 不要解释原因

意图标签："""
        
        return prompt
    
    def recognize(self, user_input, retry=3):
        """识别意图"""
        prompt = self.build_prompt(user_input)
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": self.model_name,
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.1
        }
        
        # 重试机制
        for attempt in range(retry):
            try:
                response = requests.post(
                    self.api_url, 
                    headers=headers, 
                    json=data,
                    timeout=10
                )
                
                if response.status_code == 200:
                    result = response.json()
                    intent = result['choices'][0]['message']['content'].strip()
                    
                    # 清理输出（去除可能的多余文字）
                    for intent_name in self.intent_schema.keys():
                        if intent_name in intent:
                            return intent_name
                    
                    return intent
                else:
                    print(f"API请求失败，状态码：{response.status_code}")
                    if attempt < retry - 1:
                        time.sleep(1)
                        continue
                    return "其他咨询"
            
            except Exception as e:
                print(f"API请求异常：{str(e)}")
                if attempt < retry - 1:
                    time.sleep(1)
                    continue
                return "其他咨询"
        
        return "其他咨询"

    def recognize_with_context(self, user_input, history_text="", retry=3):
        """带上下文的意图识别"""
        prompt = self.build_prompt_with_context(user_input, history_text)
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": self.model_name,
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.1
        }
        
        # 重试机制
        for attempt in range(retry):
            try:
                response = requests.post(
                    self.api_url, 
                    headers=headers, 
                    json=data,
                    timeout=10
                )
                
                if response.status_code == 200:
                    result = response.json()
                    intent = result['choices'][0]['message']['content'].strip()
                    
                    # 清理输出
                    for intent_name in self.intent_schema.keys():
                        if intent_name in intent:
                            return intent_name
                    
                    return intent
                else:
                    if attempt < retry - 1:
                        time.sleep(1)
                        continue
                    return "其他咨询"
            
            except Exception as e:
                if attempt < retry - 1:
                    time.sleep(1)
                    continue
                return "其他咨询"
        
        return "其他咨询"
    
    def build_prompt_with_context(self, user_input, history_text=""):
        """构建带上下文的Prompt"""
        intent_list = []
        for i, (intent_name, intent_info) in enumerate(self.intent_schema.items(), 1):
            examples_str = "、".join(intent_info['examples'][:3])
            intent_list.append(
                f"{i}. {intent_name}\n"
                f"   描述：{intent_info['description']}\n"
                f"   示例：{examples_str}"
            )
        
        intent_desc = "\n\n".join(intent_list)
        
        context_section = ""
        if history_text:
            context_section = f"""
对话历史：
{history_text}

"""
        
        prompt = f"""你是一个专业的客服意图识别专家。请根据用户输入和对话历史，从以下意图中选择最匹配的一个。

意图列表：
{intent_desc}

{context_section}当前用户输入：{user_input}

要求：
1. 只输出意图标签（如"咨询订单"），不要输出其他内容
2. 如果无法判断，输出"其他咨询"
3. 结合对话历史理解用户意图
4. 不要解释原因

意图标签："""
        
        return prompt
