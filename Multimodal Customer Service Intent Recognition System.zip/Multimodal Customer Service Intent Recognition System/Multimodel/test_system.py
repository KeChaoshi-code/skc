from main import IntentRecognitionSystem
import json

# 请替换为您的API Key
API_KEY = "1661f7bfead0488e8942bee88e339ed2.zC4iMdf5417Eq4Sw"

system = IntentRecognitionSystem(
    intent_schema_path='intent_schema.json',
    api_key=API_KEY,
    api_provider='zhipu'
)

# 测试案例
test_cases = [
    {"input": "我的订单什么时候发货？", "expected": "咨询订单"},
    {"input": "怎么还没发货？等了3天了", "expected": "投诉延迟"},
    {"input": "我要退款", "expected": "申请退款"},
    {"input": "这个产品怎么用？", "expected": "产品咨询"},
    {"input": "有保修吗？", "expected": "售后服务"},
    {"input": "有优惠吗？", "expected": "价格优惠"},
    {"input": "还有货吗？", "expected": "库存查询"},
    {"input": "支付失败怎么办？", "expected": "支付问题"},
    {"input": "忘记密码了", "expected": "账号问题"},
    {"input": "我要投诉", "expected": "投诉建议"},
]

print("开始测试...\n")

correct = 0
total = len(test_cases)

for i, case in enumerate(test_cases, 1):
    result = system.process(case['input'])
    predicted = result.get('intent')
    expected = case['expected']
    
    is_correct = predicted == expected
    if is_correct:
        correct += 1
        status = "✓"
    else:
        status = "✗"
    
    print(f"{status} 测试 {i}/{total}")
    print(f"  输入：{case['input']}")
    print(f"  预期：{expected}")
    print(f"  预测：{predicted}")
    print(f"  置信度：{result.get('confidence')}")
    print()

accuracy = correct / total * 100
print(f"=== 测试结果 ===")
print(f"准确率：{accuracy:.1f}% ({correct}/{total})")
