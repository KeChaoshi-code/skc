import os
import tempfile
from PIL import Image
import requests
import json

class ImageProcessor:
    def __init__(self, api_key=None, ocr_provider='paddleocr'):
        """
        图片OCR处理器
        
        ocr_provider: 'paddleocr' (本地) 或 'zhipu' (智谱AI视觉API)
        """
        self.api_key = api_key
        self.ocr_provider = ocr_provider
        
        if ocr_provider == 'paddleocr':
            from paddleocr import PaddleOCR
            # 初始化PaddleOCR（首次运行会下载模型）
            self.ocr = PaddleOCR(use_angle_cls=True, lang='ch')
        elif ocr_provider == 'zhipu':
            self.api_url = "https://open.bigmodel.cn/api/paas/v4/chat/completions"
    
    def extract_text_from_image(self, image_path ):
        """
        从图片中提取文字
        
        image_path: 图片文件路径
        """
        if self.ocr_provider == 'paddleocr':
            return self._ocr_local(image_path)
        elif self.ocr_provider == 'zhipu':
            return self._ocr_api(image_path)
    
    def _ocr_local(self, image_path):
        """使用本地PaddleOCR"""
        try:
            result = self.ocr.ocr(image_path, cls=True)
            
            # 提取所有文本
            texts = []
            for line in result[0]:
                texts.append(line[1][0])
            
            full_text = "\n".join(texts)
            return full_text, None
        
        except Exception as e:
            return None, f"OCR识别失败: {str(e)}"
    
    def _ocr_api(self, image_path):
        """使用智谱AI视觉API"""
        try:
            import base64
            
            # 读取图片并转为base64
            with open(image_path, 'rb') as img_file:
                img_base64 = base64.b64encode(img_file.read()).decode('utf-8')
            
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            data = {
                "model": "glm-4v",
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{img_base64}"
                                }
                            },
                            {
                                "type": "text",
                                "text": "请提取图片中的所有文字内容，按原样输出，不要添加任何解释。"
                            }
                        ]
                    }
                ]
            }
            
            response = requests.post(self.api_url, headers=headers, json=data)
            
            if response.status_code == 200:
                result = response.json()
                text = result['choices'][0]['message']['content']
                return text, None
            else:
                return None, f"API错误: {response.status_code}"
        
        except Exception as e:
            return None, f"OCR识别失败: {str(e)}"
    
    def extract_order_info(self, image_path):
        """从订单截图中提取关键信息"""
        text, error = self.extract_text_from_image(image_path)
        
        if error:
            return None, error
        
        # 使用正则表达式提取订单号、金额等信息
        import re
        
        info = {}
        
        # 提取订单号（常见格式）
        order_patterns = [
            r'订单号[：:]\s*([A-Z0-9]{10,})',
            r'Order\s*ID[：:]\s*([A-Z0-9]{10,})',
            r'单号[：:]\s*([A-Z0-9]{10,})'
        ]
        
        for pattern in order_patterns:
            match = re.search(pattern, text)
            if match:
                info['order_id'] = match.group(1)
                break
        
        # 提取金额
        amount_pattern = r'[¥￥]\s*(\d+\.?\d*)'
        amounts = re.findall(amount_pattern, text)
        if amounts:
            info['amount'] = amounts[0]
        
        # 提取日期
        date_pattern = r'(\d{4}[-/年]\d{1,2}[-/月]\d{1,2}[日]?)'
        dates = re.findall(date_pattern, text)
        if dates:
            info['date'] = dates[0]
        
        return {
            'raw_text': text,
            'extracted_info': info
        }, None
    
    def process_image_bytes(self, image_bytes):
        """处理图片字节流"""
        # 保存为临时文件
        with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as tmp_file:
            tmp_file.write(image_bytes)
            tmp_path = tmp_file.name
        
        try:
            result, error = self.extract_order_info(tmp_path)
            return result, error
        finally:
            # 清理临时文件
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
