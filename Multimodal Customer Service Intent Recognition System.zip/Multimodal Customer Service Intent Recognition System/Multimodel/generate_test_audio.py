"""
生成测试音频文件（需要安装 pyttsx3 或使用在线TTS服务）
"""

def generate_test_audio_online():
    """使用智谱AI生成测试音频"""
    import requests
    
    API_KEY = "your_api_key_here"
    
    # 智谱AI暂不支持TTS，这里提供替代方案
    print("请使用以下方法生成测试音频：")
    print("\n方法1：使用在线TTS服务")
    print("  - 访问：https://tts.baidu.com/" )
    print("  - 输入文本：'我的订单什么时候发货？'")
    print("  - 下载生成的音频文件")
    
    print("\n方法2：使用手机录音")
    print("  - 打开手机录音应用")
    print("  - 录制：'我的订单什么时候发货？'")
    print("  - 传输到电脑")
    
    print("\n方法3：使用Python生成（需要安装pyttsx3）")
    print("  pip install pyttsx3")
    print("  然后运行以下代码：")
    print("""
import pyttsx3

engine = pyttsx3.init()
engine.save_to_file('我的订单什么时候发货？', 'test_audio.mp3')
engine.runAndWait()
""")

if __name__ == "__main__":
    generate_test_audio_online()
