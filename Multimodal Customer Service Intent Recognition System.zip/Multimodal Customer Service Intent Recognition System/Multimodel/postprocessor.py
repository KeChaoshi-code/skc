import datetime

class PostProcessor:
    def __init__(self, intent_schema):
        self.intent_schema = intent_schema
        self.valid_intents = set(intent_schema.keys())
    
    def calculate_confidence(self, intent, user_input):
        """计算置信度（基于关键词匹配）"""
        if intent not in self.intent_schema:
            return 0.5
        
        keywords = self.intent_schema[intent].get('keywords', [])
        matched_keywords = sum(1 for kw in keywords if kw in user_input)
        
        # 基础置信度0.6，每匹配一个关键词增加0.1
        confidence = min(0.6 + matched_keywords * 0.1, 1.0)
        
        return confidence
    
    def detect_anomaly(self, intent, confidence):
        """异常检测"""
        if intent not in self.valid_intents:
            return True, "无效意图"
        if confidence < 0.5:
            return True, "置信度过低"
        return False, None
    
    def format_result(self, intent, confidence, raw_input, is_anomaly=False, error=None):
        """格式化输出"""
        return {
            "intent": intent,
            "confidence": round(confidence, 2),
            "raw_input": raw_input,
            "is_anomaly": is_anomaly,
            "error": error,
            "timestamp": datetime.datetime.now().isoformat()
        }
