from preprocessor import TextPreprocessor
from intent_recognizer import IntentRecognizer
from postprocessor import PostProcessor
import json

class IntentRecognitionSystem:
    def __init__(self, intent_schema_path, api_key, api_provider='zhipu'):
        """
        初始化系统
        
        api_provider: 'zhipu' (智谱AI，推荐) 或 'siliconflow' (硅基流动)
        """
        with open(intent_schema_path, 'r', encoding='utf-8') as f:
            intent_schema = json.load(f)
        
        self.preprocessor = TextPreprocessor()
        self.recognizer = IntentRecognizer(intent_schema_path, api_key, api_provider)
        self.postprocessor = PostProcessor(intent_schema)
    
    def process(self, user_input):
        """完整处理流程"""
        # 1. 预处理
        cleaned_text, error = self.preprocessor.preprocess(user_input)
        if error:
            return {"error": error, "raw_input": user_input}
        
        # 2. 意图识别
        intent = self.recognizer.recognize(cleaned_text)
        
        # 3. 后处理
        confidence = self.postprocessor.calculate_confidence(intent, cleaned_text)
        is_anomaly, anomaly_reason = self.postprocessor.detect_anomaly(intent, confidence)
        
        result = self.postprocessor.format_result(
            intent, confidence, user_input, is_anomaly, anomaly_reason
        )
        
        return result

if __name__ == "__main__":
    API_KEY = "1661f7bfead0488e8942bee88e339ed2.zC4iMdf5417Eq4Sw"
    
    system = IntentRecognitionSystem(
        intent_schema_path='intent_schema.json',
        api_key=API_KEY,
        api_provider='zhipu'  # 或 'siliconflow'
    )
    
    # 测试案例
    test_cases = [
        "我的订单什么时候发货？",
        "怎么还没发货？等了3天了",
        "我要退款",
        "这个产品怎么用？"
    ]
    
    for test_input in test_cases:
        result = system.process(test_input)
        print(f"\n输入：{test_input}")
        print(f"结果：{json.dumps(result, ensure_ascii=False, indent=2)}")
